<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.php">學生郵務系統</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
            data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
            aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="pkg">
                <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#menu"
                   data-parent="#exampleAccordion">
                    <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    <span class="nav-link-text">包裹管理</span>
                </a>
                <ul class="sidenav-second-level collapse" id="menu">
                    <li>
                        <a href="index.php">
                            <i class="fa fa-archive" aria-hidden="true"></i>
                            <span>包裹新增</span>
                        </a>
                    </li>
                    <li>
                        <a href="history.php">
                            <i class="fa fa-history" aria-hidden="true"></i>
                            <span>包裹歷史</span>
                        </a>
                    </li>
                </ul>
            </li>
            <!--            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">-->
            <!--                <a class="nav-link" href="index.php">-->
            <!--                    <i class="fa fa-archive" aria-hidden="true"></i>-->
            <!--                    <span class="nav-link-text">包裹管理</span>-->
            <!--                </a>-->
            <!--            </li>-->
            <?php if ($_SESSION['level'] == 1) { ?>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
                    <a class="nav-link" href="manage.php">
                        <i class="fa fa-user-secret" aria-hidden="true"></i>
                        <span class="nav-link-text">學生管理</span>
                    </a>
                </li>
            <?php } ?>
        </ul>
        <ul class="navbar-nav sidenav-toggler">
            <li class="nav-item">
                <a class="nav-link text-center" id="sidenavToggler">
                    <i class="fa fa-fw fa-angle-left"></i>
                </a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
                    <i class="fa fa-fw fa-sign-out"></i><?php echo $_SESSION['user_session']; ?></a>
            </li>
        </ul>
    </div>
</nav>

<!-- Logout Modal-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="logout.php?logout=true">Logout</a>
            </div>
        </div>
    </div>
</div><!-- Logout Modal-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="logout.php?logout=true">Logout</a>
            </div>
        </div>
    </div>
</div>